// =====================================
// SELECT FORM ELEMENTS
// =====================================

// Using getElementById
const form = document.getElementById("registrationForm");

const fullName = document.getElementById("fullName");
const email = document.getElementById("email");
const program = document.getElementById("program");
const semester = document.getElementById("semester");


// Using querySelector
const submitButton = document.querySelector(".submit-btn");
const previewCard = document.querySelector("#previewCard");


// =====================================
// SELECT PREVIEW ELEMENTS
// =====================================

const previewName = document.getElementById("previewName");
const previewEmail = document.getElementById("previewEmail");
const previewProgram = document.getElementById("previewProgram");
const previewSemester = document.getElementById("previewSemester");


// =====================================
// SELECT ERROR ELEMENTS
// =====================================

const nameError = document.getElementById("nameError");
const emailError = document.getElementById("emailError");
const programError = document.getElementById("programError");
const semesterError = document.getElementById("semesterError");


// =====================================
// LIVE PREVIEW
// input event
// =====================================

fullName.addEventListener("input", function () {

    if (fullName.value === "") {
        previewName.textContent = "Your Name";
    } else {
        previewName.textContent = fullName.value;
    }

});


email.addEventListener("input", function () {

    if (email.value === "") {
        previewEmail.textContent = "your@email.com";
    } else {
        previewEmail.textContent = email.value;
    }

});


program.addEventListener("input", function () {

    if (program.value === "") {
        previewProgram.textContent = "Not Selected";
    } else {
        previewProgram.textContent = program.value;
    }

});


semester.addEventListener("input", function () {

    if (semester.value === "") {
        previewSemester.textContent = "-";
    } else {
        previewSemester.textContent = semester.value;
    }

});


// =====================================
// FORM SUBMIT
// =====================================

form.addEventListener("submit", function (event) {

    // Stop page refresh
    event.preventDefault();


    // Clear previous errors
    nameError.textContent = "";
    emailError.textContent = "";
    programError.textContent = "";
    semesterError.textContent = "";


    let isValid = true;


    // =================================
    // VALIDATE FULL NAME
    // =================================

    if (fullName.value.trim() === "") {

        nameError.textContent = "Full Name is required.";

        isValid = false;
    }


    // =================================
    // VALIDATE EMAIL
    // =================================

    if (email.value.trim() === "") {

        emailError.textContent = "Email is required.";

        isValid = false;

    } else if (!email.value.includes("@")) {

        emailError.textContent = "Please enter a valid email.";

        isValid = false;
    }


    // =================================
    // VALIDATE PROGRAM
    // =================================

    if (program.value === "") {

        programError.textContent = "Please select a program.";

        isValid = false;
    }


    // =================================
    // VALIDATE SEMESTER
    // =================================

    if (semester.value === "") {

        semesterError.textContent = "Semester is required.";

        isValid = false;

    } else if (
        Number(semester.value) < 1 ||
        Number(semester.value) > 8
    ) {

        semesterError.textContent =
            "Semester must be between 1 and 8.";

        isValid = false;
    }


    // =================================
    // IF FORM IS VALID
    // =================================

    if (isValid) {

        // Get Registered Students list
        const studentList =
            document.getElementById("studentList");


        // Create new list item
        const listItem =
            document.createElement("li");


        // Add CSS class
        listItem.classList.add("student-item");


        // Add student information
        listItem.innerHTML = `
            <strong>${fullName.value}</strong>
            <br>
            <span>
                ${email.value} |
                ${program.value} |
                Semester ${semester.value}
            </span>
        `;


        // Add student to list
        studentList.appendChild(listItem);


        // Clear form
        form.reset();


        // Reset preview
        previewName.textContent = "Your Name";
        previewEmail.textContent = "your@email.com";
        previewProgram.textContent = "Not Selected";
        previewSemester.textContent = "-";


        alert("Student registered successfully!");

    }

});


// =====================================
// DARK MODE
// classList.toggle()
// =====================================

const themeBtn = document.getElementById("themeBtn");


themeBtn.addEventListener("click", function () {

    // Toggle dark-mode class
    document.body.classList.toggle("dark-mode");


    // Change button text
    if (document.body.classList.contains("dark-mode")) {

        themeBtn.textContent = "☀️ Light Mode";

    } else {

        themeBtn.textContent = "🌙 Dark Mode";

    }

});