/* =========================
   SELECT ELEMENTS
========================= */

const taskForm = document.getElementById("taskForm");

const taskInput = document.getElementById("taskInput");

const taskList = document.getElementById("taskList");

const errorMessage = document.getElementById("errorMessage");

const totalTasks = document.getElementById("totalTasks");

const remainingTasks =
    document.getElementById("remainingTasks");

const clearCompleted =
    document.getElementById("clearCompleted");

const filterButtons =
    document.querySelectorAll(".filter-btn");


/* =========================
   CURRENT FILTER
========================= */

let currentFilter = "all";


/* =========================
   ADD TASK
========================= */

taskForm.addEventListener("submit", function (event) {

    // Stop page refresh
    event.preventDefault();


    // Get task text
    const taskText = taskInput.value.trim();


    // Clear old error
    errorMessage.textContent = "";


    /* =====================
       EMPTY TASK CHECK
    ===================== */

    if (taskText === "") {

        errorMessage.textContent =
            "Please enter a task.";

        return;
    }


    /* =====================
       DUPLICATE CHECK
    ===================== */

    const existingTasks =
        taskList.querySelectorAll(".task-text");


    for (let task of existingTasks) {

        if (
            task.textContent.toLowerCase() ===
            taskText.toLowerCase()
        ) {

            errorMessage.textContent =
                "This task already exists.";

            return;
        }
    }


    /* =====================
       CREATE TASK
    ===================== */

    // Create list item
    const li = document.createElement("li");

    li.classList.add("task-item");


    // Create checkbox
    const checkbox =
        document.createElement("input");

    checkbox.type = "checkbox";

    checkbox.classList.add("task-checkbox");


    // Create task text
    const span =
        document.createElement("span");

    span.textContent = taskText;

    span.classList.add("task-text");


    // Create delete button
    const deleteButton =
        document.createElement("button");

    deleteButton.textContent = "Delete";

    deleteButton.classList.add("delete-btn");


    /* =====================
       ADD ELEMENTS
    ===================== */

    li.appendChild(checkbox);

    li.appendChild(span);

    li.appendChild(deleteButton);

    taskList.appendChild(li);


    /* =====================
       CLEAR INPUT
    ===================== */

    taskInput.value = "";

    taskInput.focus();


    // Update counter
    updateCounter();

    // Apply current filter
    applyFilter();

});



/* =========================
   EVENT DELEGATION
========================= */

// ONE listener for whole list
taskList.addEventListener("click", function (event) {


    /* =====================
       DELETE TASK
    ===================== */

    if (
        event.target.classList.contains("delete-btn")
    ) {

        const taskItem =
            event.target.closest(".task-item");

        taskItem.remove();

        updateCounter();

        applyFilter();

    }

});



/* =========================
   CHECKBOX EVENT
========================= */

// One listener on the list
taskList.addEventListener("change", function (event) {

    if (
        event.target.classList.contains("task-checkbox")
    ) {

        const taskItem =
            event.target.closest(".task-item");


        /* =====================
           CLASSLIST
        ===================== */

        taskItem.classList.toggle(
            "completed",
            event.target.checked
        );


        updateCounter();

        applyFilter();

    }

});



/* =========================
   UPDATE COUNTER
========================= */

function updateCounter() {

    // Get all tasks
    const tasks =
        taskList.querySelectorAll(".task-item");


    // Get completed tasks
    const completedTasks =
        taskList.querySelectorAll(
            ".task-item.completed"
        );


    // Total tasks
    const total = tasks.length;


    // Remaining tasks
    const remaining =
        total - completedTasks.length;


    // Show values
    totalTasks.textContent = total;

    remainingTasks.textContent = remaining;

}



/* =========================
   FILTER BUTTONS
========================= */

filterButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        // Remove active from all buttons
        filterButtons.forEach(function (btn) {

            btn.classList.remove("active");

        });


        // Add active to clicked button
        button.classList.add("active");


        // Get selected filter
        currentFilter =
            button.dataset.filter;


        // Apply filter
        applyFilter();

    });

});



/* =========================
   APPLY FILTER
========================= */

function applyFilter() {

    const tasks =
        taskList.querySelectorAll(".task-item");


    tasks.forEach(function (task) {

        const isCompleted =
            task.classList.contains("completed");


        if (currentFilter === "all") {

            task.style.display = "flex";

        }


        else if (
            currentFilter === "active"
        ) {

            if (isCompleted) {

                task.style.display = "none";

            } else {

                task.style.display = "flex";

            }

        }


        else if (
            currentFilter === "completed"
        ) {

            if (isCompleted) {

                task.style.display = "flex";

            } else {

                task.style.display = "none";

            }

        }

    });


    // Show empty message if needed
    showEmptyMessage();

}



/* =========================
   CLEAR COMPLETED
========================= */

clearCompleted.addEventListener(
    "click",
    function () {

        const completedTasks =
            taskList.querySelectorAll(
                ".task-item.completed"
            );


        completedTasks.forEach(function (task) {

            task.remove();

        });


        updateCounter();

        applyFilter();

    }
);



/* =========================
   EMPTY MESSAGE
========================= */

function showEmptyMessage() {

    const visibleTasks =
        Array.from(
            taskList.querySelectorAll(".task-item")
        ).filter(function (task) {

            return task.style.display !== "none";

        });


    const oldMessage =
        taskList.querySelector(".empty-message");


    if (oldMessage) {

        oldMessage.remove();

    }


    if (visibleTasks.length === 0) {

        const message =
            document.createElement("li");

        message.textContent =
            "No tasks to show.";

        message.classList.add("empty-message");

        taskList.appendChild(message);

    }

}