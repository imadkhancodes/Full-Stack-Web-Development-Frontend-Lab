let count = 0;

function increase() {
    count++;
    document.getElementById("count").textContent = count;
}

function decrease() {
    if (count > 0) {
        count--;
    }

    document.getElementById("count").textContent = count;
}

function reset() {
    count = 0;
    document.getElementById("count").textContent = count;
}

function toggleTheme() {

    document.body.classList.toggle("dark");

    let button = document.getElementById("themeBtn");

    if (document.body.classList.contains("dark")) {
        button.textContent = "Light Mode";
    } else {
        button.textContent = "Dark Mode";
    }
}