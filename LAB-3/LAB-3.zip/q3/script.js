// ===============================
// Q3: STUDENT RECORDS
// ===============================

const students = [
    {
        name: "Imad Khan",
        rollNo: "FSWD-01",
        marks: 88
    },
    {
        name: "Ali",
        rollNo: "FSWD-02",
        marks: 74
    },
    {
        name: "Ahmed",
        rollNo: "FSWD-03",
        marks: 92
    },
    {
        name: "Sara",
        rollNo: "FSWD-04",
        marks: 81
    },
    {
        name: "Hamza",
        rollNo: "FSWD-05",
        marks: 67
    }
];


// Grade Function
function getGrade(marks) {

    if (marks >= 90) {
        return "A+";
    }
    else if (marks >= 80) {
        return "A";
    }
    else if (marks >= 70) {
        return "B";
    }
    else if (marks >= 60) {
        return "C";
    }
    else {
        return "F";
    }
}


// Display Students
const table = document.getElementById("studentTable");

let totalMarks = 0;
let topStudent = students[0];

students.forEach(function(student) {

    totalMarks += student.marks;

    if (student.marks > topStudent.marks) {
        topStudent = student;
    }

    const row = `
        <tr>
            <td>${student.name}</td>
            <td>${student.rollNo}</td>
            <td>${student.marks}</td>
            <td>${getGrade(student.marks)}</td>
        </tr>
    `;

    table.innerHTML += row;
});


// Class Average
const average = totalMarks / students.length;

document.getElementById("average").textContent =
    average.toFixed(2);


// Top Scorer
document.getElementById("topScorer").textContent =
    topStudent.name;


// ===============================
// Q4: CLICK COUNTER
// ===============================

let count = 0;

const countDisplay = document.getElementById("count");


// +1
function increase() {
    count++;
    countDisplay.textContent = count;
}


// -1
function decrease() {

    if (count > 0) {
        count--;
    }

    countDisplay.textContent = count;
}


// Reset
function reset() {
    count = 0;
    countDisplay.textContent = count;
}


// ===============================
// DARK MODE
// ===============================

function toggleTheme() {

    document.body.classList.toggle("dark");

    const button = document.getElementById("themeBtn");

    if (document.body.classList.contains("dark")) {
        button.textContent = "Light Mode";
    }
    else {
        button.textContent = "Dark Mode";
    }
}