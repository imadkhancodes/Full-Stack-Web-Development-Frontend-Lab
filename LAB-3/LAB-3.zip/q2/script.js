
function generateFizzBuzz() {

    // Get the upper limit
    let limit = Number(document.getElementById("limit").value);

    // Get the list
    let list = document.getElementById("fizzBuzzList");

    // Clear old list
    list.innerHTML = "";

    // Check input
    if (limit < 1 || isNaN(limit)) {
        list.innerHTML = "<li>Please enter a valid number.</li>";
        return;
    }

    // Loop from 1 to limit
    for (let i = 1; i <= limit; i++) {

        let item = document.createElement("li");

        // Multiple of both 3 and 5
        if (i % 3 === 0 && i % 5 === 0) {
            item.innerHTML = "FizzBuzz";
        }

        // Multiple of 3
        else if (i % 3 === 0) {
            item.innerHTML = "Fizz";
        }

        // Multiple of 5
        else if (i % 5 === 0) {
            item.innerHTML = "Buzz";
        }

        // Normal number
        else {
            item.innerHTML = i;
        }

        // Add item to the <ul>
        list.appendChild(item);
    }
}


// Generate default list from 1 to 30
generateFizzBuzz();
