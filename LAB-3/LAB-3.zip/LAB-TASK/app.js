const nameInput = document.getElementById("name");
const marksInput = document.getElementById("marks");
const calcBtn = document.getElementById("calcBtn");
const result = document.getElementById("result");

calcBtn.addEventListener("click", function () {


const studentName = nameInput.value.trim();
const marks = Number(marksInput.value);

// Validation
if (studentName === "") {

    result.textContent = "Error: Please enter the student name.";
    result.className = "error";
}
else if (marksInput.value === "" || marks < 0 || marks > 100) {

    result.textContent = "Error: Please enter marks between 0 and 100.";
    result.className = "error";

}

// Grade A
else if (marks >= 85) {

    const grade = "A";

    result.textContent =
        `${studentName} scored ${marks} → Grade ${grade}`;

    result.className = "success";
}

// Grade B
else if (marks >= 70) {

    const grade = "B";

    result.textContent =
        `${studentName} scored ${marks} → Grade ${grade}`;

    result.className = "success";
}

// Grade C
else if (marks >= 50) {

    const grade = "C";

    result.textContent =
        `${studentName} scored ${marks} → Grade ${grade}`;

    result.className = "success";
}

// Grade F
else {

    const grade = "F";

    result.textContent =
        `${studentName} scored ${marks} → Grade ${grade}`;

    result.className = "error";
}

});
