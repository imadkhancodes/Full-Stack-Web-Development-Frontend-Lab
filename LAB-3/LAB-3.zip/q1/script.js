
// Celsius to Fahrenheit
function celsiusToFahrenheit(c) {
    return (c * 9 / 5) + 32;
}


// Fahrenheit to Celsius
const fahrenheitToCelsius = (f) => {
    return (f - 32) * 5 / 9;
};


// Convert Celsius to Fahrenheit
function convertToFahrenheit() {

    let input = document.getElementById("temperature").value;
    let result = document.getElementById("result");

    // Check empty or invalid input
    if (input.trim() === "" || isNaN(input)) {
        result.innerHTML = "⚠️ Please enter a valid number.";
        return;
    }

    let celsius = Number(input);

    let fahrenheit = celsiusToFahrenheit(celsius);

    result.innerHTML =
        celsius + " °C = " + fahrenheit.toFixed(1) + " °F";
}


// Convert Fahrenheit to Celsius
function convertToCelsius() {

    let input = document.getElementById("temperature").value;
    let result = document.getElementById("result");

    // Check empty or invalid input
    if (input.trim() === "" || isNaN(input)) {
        result.innerHTML = "⚠️ Please enter a valid number.";
        return;
    }

    let fahrenheit = Number(input);

    let celsius = fahrenheitToCelsius(fahrenheit);

    result.innerHTML =
        fahrenheit + " °F = " + celsius.toFixed(1) + " °C";
}
