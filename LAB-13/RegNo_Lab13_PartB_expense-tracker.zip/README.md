# Expense Tracker - Lab 13 Assignment

A small React + Vite app for tracking personal expenses, built around
useReducer, Context, custom hooks and memoization.

## Run it

```bash
npm install
npm run dev
```

Open the printed local URL (usually http://localhost:5173).

```bash
npm run build
```

## Project structure

```
src/
  hooks/
    useLocalStorage.js   generic localStorage-backed state
    useDebounce.js       NEW hook - delays a value until typing pauses
    useFetch.js          generic fetch hook with an offline fallback
  context/
    ExpenseContext.jsx    ExpenseProvider + useExpenses(), useReducer + localStorage
    ThemeContext.jsx       dark/light theme, same pattern as ExpenseContext
    reducer.js             the add / delete / clearAll reducer
  components/
    ExpenseForm.jsx        controlled inputs, validation, useRef focus
    ExpenseRow.jsx          memo()-wrapped single row
    ExpenseList.jsx         renders rows, useCallback for the delete handler
    Summary.jsx             useMemo: total, count, per-category totals
    SearchBar.jsx           debounced search input
    ImportExpenses.jsx      useFetch + "Import as expenses" button
public/
  todos.json              offline fallback for the 5 sample titles
```

## Notes on the requirements

- Expenses are `{ id, title, amount, category }`, stored with `useReducer`
  in `ExpenseContext`, and saved to `localStorage` on every change, then
  loaded back on startup.
- `useDebounce` is the new custom hook: it returns a copy of a value that
  only updates after the user stops typing for 300ms, so the search filter
  (built with `useMemo`) doesn't re-run on every keystroke.
- `ExpenseForm` validates that the title isn't empty and the amount is a
  number greater than 0, showing a red message otherwise. After adding an
  expense, `useRef` is used to return focus to the title field.
- `ExpenseList` uses `useCallback` for the delete handler and `ExpenseRow`
  is wrapped in `memo()`, so unrelated re-renders don't re-render every row.
- `Summary` recomputes the total, count and per-category totals with
  `useMemo`, only when the expenses array changes.
- The "Import as expenses" button uses `useFetch` to load 5 sample titles
  from `https://jsonplaceholder.typicode.com/todos?_limit=5`, with
  `public/todos.json` as an offline fallback, and shows loading/error
  states.
- Dark/light theme is a second Context (`ThemeContext`), following the
  same Provider + custom-hook pattern as `ExpenseContext`.

## Screenshots

See `Evidence/` in the submission zip for the required screenshots.
