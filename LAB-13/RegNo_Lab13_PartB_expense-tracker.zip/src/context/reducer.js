// Author: Student Name | Reg No: FA21-BCS-000\n
// Reducer shape follows the lab's hint, with items shaped as
// { id, title, amount, category } instead of { id, item }.
//
// Note: Date.now() alone is NOT safe here, because the "Import as expenses"
// feature dispatches several 'add' actions back-to-back in the same tick,
// and on a fast machine they can all get the exact same millisecond
// timestamp - producing duplicate ids (and duplicate React keys, which
// causes rows to render incorrectly). Adding an incrementing counter makes
// every id unique even when several items are added in the same instant.
let nextId = 0
function makeId() {
  nextId += 1
  return Date.now() + '-' + nextId
}

export function expenseReducer(state, action) {
  switch (action.type) {
    case 'add':
      return [...state, { id: makeId(), ...action.item }]
    case 'delete':
      return state.filter((e) => e.id !== action.id)
    case 'clearAll':
      return []
    default:
      return state
  }
}
