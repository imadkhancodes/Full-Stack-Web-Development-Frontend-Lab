// Author: Student Name | Reg No: FA21-BCS-000\n
import { createContext, useContext, useReducer, useEffect } from 'react'
import { expenseReducer } from './reducer.js'

const ExpenseContext = createContext(null)
const STORAGE_KEY = 'expenses'

function loadInitial() {
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY)
    return stored ? JSON.parse(stored) : []
  } catch {
    return []
  }
}

export function ExpenseProvider({ children }) {
  const [expenses, dispatch] = useReducer(expenseReducer, undefined, loadInitial)

  // Save to localStorage every time the expenses array changes.
  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(expenses))
    } catch {
      // ignore write errors
    }
  }, [expenses])

  return (
    <ExpenseContext.Provider value={{ expenses, dispatch }}>
      {children}
    </ExpenseContext.Provider>
  )
}

export function useExpenses() {
  return useContext(ExpenseContext)
}
