// Author: Student Name | Reg No: FA21-BCS-000\n
import { useState, useMemo } from 'react'
import { useExpenses } from './context/ExpenseContext.jsx'
import { useTheme } from './context/ThemeContext.jsx'
import ExpenseForm from './components/ExpenseForm.jsx'
import ExpenseList from './components/ExpenseList.jsx'
import Summary from './components/Summary.jsx'
import SearchBar from './components/SearchBar.jsx'
import ImportExpenses from './components/ImportExpenses.jsx'

function App() {
  const { expenses, dispatch } = useExpenses()
  const { theme, toggleTheme } = useTheme()
  const [search, setSearch] = useState('')

  // Recomputed only when expenses or the debounced search term change.
  const visibleExpenses = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (!term) return expenses
    return expenses.filter(
      (e) => e.title.toLowerCase().includes(term) || e.category.toLowerCase().includes(term)
    )
  }, [expenses, search])

  return (
    <div className="app">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Expense Tracker</h1>
        <button className="btn btn-outline" onClick={toggleTheme}>
          {theme === 'light' ? 'Dark mode' : 'Light mode'}
        </button>
      </div>

      <ExpenseForm />
      <ImportExpenses />

      <div className="card">
        <h2>Search / filter</h2>
        <div className="row">
          <SearchBar onChange={setSearch} />
          <button className="btn btn-danger" onClick={() => dispatch({ type: 'clearAll' })}>
            Clear all
          </button>
        </div>
      </div>

      <Summary />
      <ExpenseList visibleExpenses={visibleExpenses} />
    </div>
  )
}

export default App
