// Author: Student Name | Reg No: FA21-BCS-000\n
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import { ExpenseProvider } from './context/ExpenseContext.jsx'
import { ThemeProvider, useTheme } from './context/ThemeContext.jsx'
import './index.css'

function ThemedBody({ children }) {
  const { theme } = useTheme()
  document.body.className = theme
  return children
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ThemeProvider>
      <ExpenseProvider>
        <ThemedBody>
          <App />
        </ThemedBody>
      </ExpenseProvider>
    </ThemeProvider>
  </React.StrictMode>
)
