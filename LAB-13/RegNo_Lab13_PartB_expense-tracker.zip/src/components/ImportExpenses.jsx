// Author: Student Name | Reg No: FA21-BCS-000\n
import { useFetch } from '../hooks/useFetch.js'
import { useExpenses } from '../context/ExpenseContext.jsx'

const LIVE_URL = 'https://jsonplaceholder.typicode.com/todos?_limit=5'
const FALLBACK_URL = '/todos.json'

function ImportExpenses() {
  const { data, loading, error } = useFetch(LIVE_URL, FALLBACK_URL)
  const { dispatch } = useExpenses()

  function handleImport() {
    if (!data) return
    data.slice(0, 5).forEach((todo) => {
      dispatch({ type: 'add', item: { title: todo.title, amount: 100, category: 'Other' } })
    })
  }

  return (
    <div className="card">
      <h2>Import sample expenses</h2>
      {loading && <p>Loading sample titles...</p>}
      {error && <p className="error-text">{error}</p>}
      {!loading && !error && (
        <>
          <p style={{ fontSize: 13, opacity: 0.7 }}>
            Pulls 5 sample titles and adds each as an expense of Rs 100 in the "Other" category.
          </p>
          <button className="btn btn-secondary" onClick={handleImport}>
            Import as expenses
          </button>
        </>
      )}
    </div>
  )
}

export default ImportExpenses
