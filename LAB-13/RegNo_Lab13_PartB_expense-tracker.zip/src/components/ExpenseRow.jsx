// Author: Student Name | Reg No: FA21-BCS-000\n
import { memo } from 'react'

// memo() skips re-rendering this row if its props haven't changed - useful
// once the list has many rows and only one of them actually changes.
const ExpenseRow = memo(function ExpenseRow({ expense, onDelete }) {
  return (
    <div className="expense-row">
      <span className="expense-title">{expense.title}</span>
      <span className="expense-category">{expense.category}</span>
      <span className="expense-amount">Rs {expense.amount.toFixed(2)}</span>
      <button className="btn btn-outline" onClick={() => onDelete(expense.id)}>Delete</button>
    </div>
  )
})

export default ExpenseRow
