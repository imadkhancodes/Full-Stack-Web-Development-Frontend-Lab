// Author: Student Name | Reg No: FA21-BCS-000\n
import { useMemo } from 'react'
import { useExpenses } from '../context/ExpenseContext.jsx'

function Summary() {
  const { expenses } = useExpenses()

  // Recomputed only when the expenses array actually changes.
  const { total, count, perCategory } = useMemo(() => {
    const total = expenses.reduce((sum, e) => sum + e.amount, 0)
    const perCategory = {}
    for (const e of expenses) {
      perCategory[e.category] = (perCategory[e.category] || 0) + e.amount
    }
    return { total, count: expenses.length, perCategory }
  }, [expenses])

  return (
    <div className="card">
      <h2>Summary</h2>
      <p className="stats">Total: Rs {total.toFixed(2)} | Count: {count}</p>
      {Object.keys(perCategory).length === 0 && <p>No expenses yet.</p>}
      <ul className="category-list">
        {Object.entries(perCategory).map(([cat, amt]) => (
          <li key={cat}>{cat}: Rs {amt.toFixed(2)}</li>
        ))}
      </ul>
    </div>
  )
}

export default Summary
