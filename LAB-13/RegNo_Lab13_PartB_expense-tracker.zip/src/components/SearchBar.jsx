// Author: Student Name | Reg No: FA21-BCS-000\n
import { useState, useEffect } from 'react'
import { useDebounce } from '../hooks/useDebounce.js'

function SearchBar({ onChange }) {
  const [text, setText] = useState('')
  const debouncedText = useDebounce(text, 300)

  // Notify the parent only once the debounced value settles, not on every keystroke.
  useEffect(() => {
    onChange(debouncedText)
  }, [debouncedText, onChange])

  return (
    <input
      type="text"
      placeholder="Search by title or category..."
      value={text}
      onChange={(e) => setText(e.target.value)}
    />
  )
}

export default SearchBar
