// Author: Student Name | Reg No: FA21-BCS-000\n
import { useState, useRef } from 'react'
import { useExpenses } from '../context/ExpenseContext.jsx'

const CATEGORIES = ['Food', 'Transport', 'Bills', 'Shopping', 'Other']

function ExpenseForm() {
  const { dispatch } = useExpenses()
  const [title, setTitle] = useState('')
  const [amount, setAmount] = useState('')
  const [category, setCategory] = useState(CATEGORIES[0])
  const [error, setError] = useState('')
  const titleRef = useRef(null)

  function handleSubmit(e) {
    e.preventDefault()

    if (!title.trim()) {
      setError('Title cannot be empty.')
      return
    }
    const numericAmount = Number(amount)
    if (!amount || Number.isNaN(numericAmount) || numericAmount <= 0) {
      setError('Amount must be a number greater than 0.')
      return
    }

    dispatch({ type: 'add', item: { title: title.trim(), amount: numericAmount, category } })
    setTitle('')
    setAmount('')
    setError('')
    titleRef.current.focus() // useRef: return focus to the title field after adding
  }

  return (
    <form className="card" onSubmit={handleSubmit}>
      <h2>Add expense</h2>
      <div className="row">
        <input
          ref={titleRef}
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          type="text"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <button className="btn btn-primary" type="submit">Add</button>
      </div>
      {error && <p className="error-text">{error}</p>}
    </form>
  )
}

export default ExpenseForm
