// Author: Student Name | Reg No: FA21-BCS-000\n
import { useCallback } from 'react'
import { useExpenses } from '../context/ExpenseContext.jsx'
import ExpenseRow from './ExpenseRow.jsx'

function ExpenseList({ visibleExpenses }) {
  const { dispatch } = useExpenses()

  // useCallback: the delete handler keeps the same identity across renders,
  // so memoized ExpenseRow children don't re-render just because the list
  // component itself re-rendered.
  const handleDelete = useCallback((id) => {
    dispatch({ type: 'delete', id })
  }, [dispatch])

  return (
    <div className="card">
      <h2>Expenses</h2>
      {visibleExpenses.length === 0 && <p>No expenses to show.</p>}
      {visibleExpenses.map((expense) => (
        <ExpenseRow key={expense.id} expense={expense} onDelete={handleDelete} />
      ))}
    </div>
  )
}

export default ExpenseList
