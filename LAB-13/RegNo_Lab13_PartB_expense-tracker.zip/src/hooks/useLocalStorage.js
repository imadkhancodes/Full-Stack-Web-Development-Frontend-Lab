// Author: Student Name | Reg No: FA21-BCS-000\n
import { useState, useEffect } from 'react'

// Reusable hook: behaves like useState, but reads the initial value from
// localStorage and writes every update back to it, so state survives a
// page refresh. Used by ExpenseContext (expenses) and ThemeContext (theme).
export function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const stored = window.localStorage.getItem(key)
      return stored !== null ? JSON.parse(stored) : initialValue
    } catch {
      return initialValue
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value))
    } catch {
      // ignore write errors
    }
  }, [key, value])

  return [value, setValue]
}
