// Author: Student Name | Reg No: FA21-BCS-000\n
import { useState, useEffect } from 'react'

// Generic data-fetching hook: given a URL, returns { data, loading, error }.
// Tries the live URL first and falls back to a local JSON file if that
// request fails (e.g. a blocked network), as the lab hint suggests.
export function useFetch(url, fallbackUrl) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    setError(null)

    fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error('Network response was not ok (' + res.status + ')')
        return res.json()
      })
      .then((json) => { if (!cancelled) setData(json) })
      .catch(() => {
        // live request failed - fall back to the local copy
        if (!fallbackUrl) { if (!cancelled) setError('Could not load data.'); return }
        fetch(fallbackUrl)
          .then((res) => res.json())
          .then((json) => { if (!cancelled) setData(json) })
          .catch(() => { if (!cancelled) setError('Could not load data, online or offline.') })
      })
      .finally(() => { if (!cancelled) setLoading(false) })

    return () => { cancelled = true }
  }, [url, fallbackUrl])

  return { data, loading, error }
}
