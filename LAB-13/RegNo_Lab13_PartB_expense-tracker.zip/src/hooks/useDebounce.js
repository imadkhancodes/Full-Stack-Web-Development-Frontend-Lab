// Author: Student Name | Reg No: FA21-BCS-000\n
import { useState, useEffect } from 'react'

// New hook (assignment requirement): useDebounce(value, delay) returns a
// copy of "value" that only updates after the user has stopped changing it
// for "delay" milliseconds. Used on the search box so filtering doesn't
// re-run on every single keystroke, only once typing pauses.
export function useDebounce(value, delay = 300) {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay)
    // if value changes again before the timer fires, cancel the old timer
    return () => clearTimeout(timer)
  }, [value, delay])

  return debounced
}
