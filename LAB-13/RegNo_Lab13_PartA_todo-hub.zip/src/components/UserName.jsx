import { useUser } from '../context/UserContext.jsx'

// Task 3: reads and writes the name purely through useUser() - no props
// are passed in from App.jsx at all.
function UserName() {
  const { name, setName } = useUser()

  return (
    <div className="card">
      <h2>Your name</h2>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <p style={{ fontSize: 13, opacity: 0.7 }}>
        Change the name, then refresh the page - it is saved in localStorage via useLocalStorage.
      </p>
    </div>
  )
}

export default UserName
