import { useEffect } from 'react'
import { useCounter } from '../hooks/useCounter.js'

// Task 1: HooksRecap now uses the useCounter custom hook instead of its own
// useState counter. The useEffect that updates the tab title is unchanged,
// so it still reacts to count changes exactly as before.
function HooksRecap() {
  const { count, increment, decrement, reset } = useCounter(0, 1)

  useEffect(() => {
    document.title = `Count: ${count} - Todo Hub`
  }, [count])

  return (
    <div className="card">
      <h2>Hooks Recap</h2>
      <div className="row">
        <button className="btn btn-outline" onClick={decrement}>-</button>
        <span className="counter-value">{count}</span>
        <button className="btn btn-outline" onClick={increment}>+</button>
        <button className="btn btn-secondary" onClick={reset}>Reset</button>
      </div>
      <p style={{ fontSize: 13, opacity: 0.7 }}>
        Counter state now lives in the useCounter custom hook. Watch the browser tab title change.
      </p>
    </div>
  )
}

export default HooksRecap
