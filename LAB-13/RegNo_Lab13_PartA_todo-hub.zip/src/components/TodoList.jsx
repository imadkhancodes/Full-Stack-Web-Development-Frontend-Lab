import { useState } from 'react'
import { useTodos } from '../context/TodoContext.jsx'

function TodoList() {
  const { todos, dispatch } = useTodos()
  const [text, setText] = useState('')

  const doneCount = todos.filter((t) => t.done).length

  function handleAdd(e) {
    e.preventDefault()
    if (!text.trim()) return
    dispatch({ type: 'add', text: text.trim() })
    setText('')
  }

  return (
    <div className="card">
      <h2>Todo List</h2>

      <form className="row" onSubmit={handleAdd}>
        <input
          type="text"
          placeholder="New todo..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button className="btn btn-primary" type="submit">Add</button>
      </form>

      <p className="stats">Done: {doneCount} / Total: {todos.length}</p>

      {/* Task 2: two new buttons dispatching the new reducer actions */}
      <div className="row">
        <button className="btn btn-secondary" onClick={() => dispatch({ type: 'markAllDone' })}>
          Mark all done
        </button>
        <button className="btn btn-danger" onClick={() => dispatch({ type: 'clearAll' })}>
          Clear all
        </button>
      </div>

      {todos.map((t) => (
        <div key={t.id} className={`todo-item ${t.done ? 'done' : ''}`}>
          <input
            type="checkbox"
            checked={t.done}
            onChange={() => dispatch({ type: 'toggle', id: t.id })}
          />
          <span>{t.text}</span>
          <button className="btn btn-outline" onClick={() => dispatch({ type: 'delete', id: t.id })}>
            Delete
          </button>
        </div>
      ))}

      {todos.length === 0 && <p>No todos left.</p>}
    </div>
  )
}

export default TodoList
