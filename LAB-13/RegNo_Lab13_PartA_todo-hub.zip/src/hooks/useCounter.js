import { useState, useCallback } from 'react'

// Task 1: custom hook that packages up a counter's state and the three
// actions that change it, so any component can reuse it with one line.
export function useCounter(start = 0, step = 1) {
  const [count, setCount] = useState(start)

  // useCallback keeps the same function reference across re-renders,
  // so components that receive these as props don't re-render needlessly.
  const increment = useCallback(() => setCount((c) => c + step), [step])
  const decrement = useCallback(() => setCount((c) => c - step), [step])
  const reset = useCallback(() => setCount(start), [start])

  return { count, increment, decrement, reset }
}
