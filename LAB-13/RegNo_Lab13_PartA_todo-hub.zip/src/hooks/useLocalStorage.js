import { useState, useEffect } from 'react'

// Small reusable hook: behaves like useState, but the value is read from
// (and written back to) localStorage, so it survives a page refresh.
export function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const stored = window.localStorage.getItem(key)
      return stored !== null ? JSON.parse(stored) : initialValue
    } catch {
      return initialValue
    }
  })

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value))
    } catch {
      // ignore write errors (e.g. storage full or disabled)
    }
  }, [key, value])

  return [value, setValue]
}
