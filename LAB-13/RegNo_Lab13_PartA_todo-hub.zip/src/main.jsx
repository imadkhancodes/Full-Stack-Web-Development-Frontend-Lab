import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import { ThemeProvider, useTheme } from './context/ThemeContext.jsx'
import { TodoProvider } from './context/TodoContext.jsx'
import { UserProvider } from './context/UserContext.jsx'
import './index.css'

// Applies the body.light / body.dark class so index.css can theme the page.
function ThemedBody({ children }) {
  const { theme } = useTheme()
  document.body.className = theme
  return children
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ThemeProvider>
      <UserProvider>
        <TodoProvider>
          <ThemedBody>
            <App />
          </ThemedBody>
        </TodoProvider>
      </UserProvider>
    </ThemeProvider>
  </React.StrictMode>
)
