import HooksRecap from './components/HooksRecap.jsx'
import TodoList from './components/TodoList.jsx'
import UserName from './components/UserName.jsx'
import { useUser } from './context/UserContext.jsx'
import { useTheme } from './context/ThemeContext.jsx'

function App() {
  const { name } = useUser()
  const { theme, toggleTheme } = useTheme()

  return (
    <div className="app">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Hello, {name}</h1>
        <button className="btn btn-outline" onClick={toggleTheme}>
          {theme === 'light' ? 'Dark mode' : 'Light mode'}
        </button>
      </div>

      <HooksRecap />
      <UserName />
      <TodoList />
    </div>
  )
}

export default App
