import { createContext, useContext, useReducer } from 'react'

const TodoContext = createContext(null)

const initialTodos = [
  { id: 1, text: 'Finish Lab 13 slides', done: false },
  { id: 2, text: 'Revise useReducer notes', done: true },
  { id: 3, text: 'Push code to GitHub', done: false },
]

function reducer(state, action) {
  switch (action.type) {
    case 'add':
      return [...state, { id: Date.now(), text: action.text, done: false }]
    case 'toggle':
      return state.map((t) => (t.id === action.id ? { ...t, done: !t.done } : t))
    case 'delete':
      return state.filter((t) => t.id !== action.id)
    // Task 2: two new actions, both return a brand new array (never mutate state)
    case 'markAllDone':
      return state.map((t) => ({ ...t, done: true }))
    case 'clearAll':
      return []
    default:
      return state
  }
}

export function TodoProvider({ children }) {
  const [todos, dispatch] = useReducer(reducer, initialTodos)
  return (
    <TodoContext.Provider value={{ todos, dispatch }}>
      {children}
    </TodoContext.Provider>
  )
}

export function useTodos() {
  return useContext(TodoContext)
}
