import { createContext, useContext } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage.js'

const UserContext = createContext(null)

// Task 3: follows the exact same pattern as ThemeContext - a Provider that
// owns the state (persisted with useLocalStorage) and a matching useX() hook.
export function UserProvider({ children }) {
  const [name, setName] = useLocalStorage('userName', 'Guest')
  return (
    <UserContext.Provider value={{ name, setName }}>
      {children}
    </UserContext.Provider>
  )
}

export function useUser() {
  return useContext(UserContext)
}
