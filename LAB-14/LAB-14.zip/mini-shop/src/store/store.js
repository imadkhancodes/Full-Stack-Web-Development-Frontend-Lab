// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { configureStore } from '@reduxjs/toolkit';
import cartReducer from './cartSlice.js';
import wishlistReducer from './wishlistSlice.js';

export const store = configureStore({
  reducer: {
    wishlist: wishlistReducer,
    cart: cartReducer,
  },
});
