// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { removeFromCart, selectCartItems } from '../store/cartSlice.js';
import { products } from '../data/products.js';

export default function CartPage() {
  const dispatch = useDispatch();
  const items = useSelector(selectCartItems);

  // Join each cart item with its product details
  const rows = items.map((i) => ({ ...products.find((p) => p.id === i.id), qty: i.qty }));
  const total = rows.reduce((sum, r) => sum + r.price * r.qty, 0);

  return (
    <section className="wishlist">
      <h1>My Cart</h1>

      {rows.length === 0 ? (
        <p className="empty">Your cart is empty.</p>
      ) : (
        <>
          <ul className="wish-list">
            {rows.map((r) => (
              <li key={r.id}>
                <span className="wish-icon" aria-hidden="true">{r.icon}</span>
                <Link to={`/product/${r.id}`}>{r.title}</Link>
                <span>x {r.qty}</span>
                <span className="price">Rs. {(r.price * r.qty).toLocaleString()}</span>
                <button type="button" className="btn outline" onClick={() => dispatch(removeFromCart(r.id))}>
                  Remove
                </button>
              </li>
            ))}
          </ul>
          <p className="price">Total: Rs. {total.toLocaleString()}</p>
          <Link to="/checkout" className="btn inline">
            Go to Checkout
          </Link>
        </>
      )}
    </section>
  );
}
