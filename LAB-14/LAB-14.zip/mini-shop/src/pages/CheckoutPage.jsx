// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { clearCart, selectCartItems } from '../store/cartSlice.js';
import { products } from '../data/products.js';

const emptyForm = {
  name: '',
  email: '',
  phone: '',
  address: '',
  payment: 'Cash on Delivery',
  easypaisa: '',
  acceptReturn: false,
};

// Returns an object holding one message for each invalid field
function validate(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = 'Name is required';
  if (!/^\S+@\S+\.\S+$/.test(form.email)) errors.email = 'Enter a valid email';
  if (!/^\d{11}$/.test(form.phone)) errors.phone = 'Phone must be 11 digits';
  if (!form.address.trim()) errors.address = 'Address is required';
  // The Easypaisa number is checked only when that option is selected
  if (form.payment === 'Easypaisa' && !/^03\d{9}$/.test(form.easypaisa))
    errors.easypaisa = 'Enter an 11 digit number starting with 03';
  if (!form.acceptReturn) errors.acceptReturn = 'Please accept the return conditions';
  return errors;
}

export default function CheckoutPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const items = useSelector(selectCartItems);
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  // Stops the empty cart redirect after a successful order
  const [submitted, setSubmitted] = useState(false);

  const total = items.reduce(
    (sum, i) => sum + products.find((p) => p.id === i.id).price * i.qty,
    0
  );

  // One handler for all inputs: copy the form, then update one field
  function handleChange(e) {
    const { name, value, type, checked } = e.target;
    // A checkbox stores true or false instead of text
    setForm({ ...form, [name]: type === 'checkbox' ? checked : value });
    // Hide this field's error while the user is correcting it
    setErrors({ ...errors, [name]: undefined });
  }

  function handleSubmit(e) {
    e.preventDefault(); // stop the page from reloading
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitted(true);
    navigate('/thank-you', { state: { name: form.name.trim(), payment: form.payment } });
    dispatch(clearCart());
  }

  // Checkout needs at least one item in the cart
  if (items.length === 0 && !submitted) return <Navigate to="/cart" replace />;

  const fields = [
    { name: 'name', label: 'Full Name', type: 'text' },
    { name: 'email', label: 'Email', type: 'email' },
    { name: 'phone', label: 'Phone (11 digits)', type: 'tel' },
    { name: 'address', label: 'Delivery Address', type: 'text' },
  ];

  return (
    <section className="narrow">
      <h1>Checkout</h1>
      <form className="checkout" onSubmit={handleSubmit} noValidate>
        {fields.map((f) => (
          <label key={f.name}>
            {f.label}
            <input
              name={f.name}
              type={f.type}
              value={form[f.name]}
              onChange={handleChange}
            />
            {errors[f.name] && <span className="error">{errors[f.name]}</span>}
          </label>
        ))}
        {/* Controlled radio buttons: "checked" comes from state */}
        <fieldset>
          <legend>Payment Method</legend>
          {['Cash on Delivery', 'Easypaisa'].map((method) => (
            <label key={method} className="choice">
              <input
                type="radio"
                name="payment"
                value={method}
                checked={form.payment === method}
                onChange={handleChange}
              />
              {method}
            </label>
          ))}
        </fieldset>

        {form.payment === 'Easypaisa' && (
          <label>
            Easypaisa Mobile Number
            <input name="easypaisa" type="tel" value={form.easypaisa} onChange={handleChange} />
            {errors.easypaisa && <span className="error">{errors.easypaisa}</span>}
          </label>
        )}

        <fieldset>
          <legend>Return Conditions</legend>
          <ul>
            <li>Items can be returned within 7 days of delivery.</li>
            <li>Items must be unused and in original packaging.</li>
            <li>A receipt or order proof is required.</li>
          </ul>
          <label className="choice">
            <input
              type="checkbox"
              name="acceptReturn"
              checked={form.acceptReturn}
              onChange={handleChange}
            />
            I accept the return conditions
          </label>
          {errors.acceptReturn && <span className="error">{errors.acceptReturn}</span>}
        </fieldset>
        <p className="price">Total: Rs. {total.toLocaleString()}</p>
        <button type="submit" className="btn">
          Submit Order
        </button>
      </form>
    </section>
  );
}
