// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { useState } from 'react';
import ProductCard from '../components/ProductCard.jsx';
import { products } from '../data/products.js';

// Unique category names for the select box
const categories = ['All', ...new Set(products.map((p) => p.category))];

export default function HomePage() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');

  // A product must match both the category and the search text
  const visible = products.filter((p) => {
    const matchesCategory = category === 'All' || p.category === category;
    const matchesTitle = p.title.toLowerCase().includes(search.trim().toLowerCase());
    return matchesCategory && matchesTitle;
  });

  return (
    <section>
      <header className="hero">
        <h1>Find your next favourite</h1>
        <p>Books, electronics and accessories in one place.</p>
      </header>

      <div className="filters">
        {/* Controlled input: its value always comes from state */}
        <label>
          Search by title
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by title"
          />
        </label>

        <label>
          Category
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
      </div>

      {visible.length === 0 ? (
        <p className="empty">No products found</p>
      ) : (
        <div className="grid">
          {visible.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </section>
  );
}
