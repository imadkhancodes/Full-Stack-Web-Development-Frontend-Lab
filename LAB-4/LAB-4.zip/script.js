// 1. Create Student class
class Student {

    constructor(name, marks) {
        this.name = name;
        this.marks = marks;
    }

    // Get grade
    getGrade() {

        if (this.marks >= 80) {
            return "A";
        }
        else if (this.marks >= 70) {
            return "B";
        }
        else if (this.marks >= 60) {
            return "C";
        }
        else if (this.marks >= 50) {
            return "D";
        }
        else {
            return "F";
        }
    }
}


// 2. Create at least 6 Student objects
const students = [
    new Student("Imad Khan", 85),
    new Student("Ahmed", 72),
    new Student("Sara", 91),
    new Student("Ali", 48),
    new Student("Usman", 65),
    new Student("Hassan", 55)
];


// Display students on webpage
const studentList = document.getElementById("students");

students.forEach(student => {

    // 5. Ternary operator for Pass / Fail
    const status = student.marks >= 50 ? "Pass" : "Fail";

    studentList.innerHTML += `
        <div class="student">
            <span>
                <strong>${student.name}</strong>
                - ${student.marks} marks
                - Grade: ${student.getGrade()}
            </span>

            <span class="${status === "Pass" ? "pass" : "fail"}">
                ${status}
            </span>
        </div>
    `;
});


// 3. filter() - get passing students
const passingStudents = students.filter(student => student.marks >= 50);


// map() - get only passing students' names
const passingNames = passingStudents.map(student => student.name);


// 4. reduce() - calculate class average
const totalMarks = students.reduce((total, student) => {
    return total + student.marks;
}, 0);

const classAverage = totalMarks / students.length;


// sort() - sort students by marks
const sortedStudents = [...students].sort((a, b) => {
    return b.marks - a.marks;
});


// Destructuring - get top scorer
const [topScorer] = sortedStudents;


// 6. Console output
console.log("Passing Students:", passingNames);

console.log("Class Average:", classAverage.toFixed(2));

console.log("Top Scorer:", topScorer.name);

console.log("Top Scorer Marks:", topScorer.marks);


